library(testthat)
library(GlobalOptions)

test_check("GlobalOptions")
