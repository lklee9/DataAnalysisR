setLoadActions(function(ns) {
	circos.par("__tempdir__" = tempdir())
})
